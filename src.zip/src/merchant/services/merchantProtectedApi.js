// src/services/merchantApi.js
// Merchant endpoints — use merchantFetch so Authorization is attached only here

import { clearMerchantAuth } from "../auth/merchantAuth";
import { merchantFetch } from "./merchantHttpClient";

export const merchantAuthApi = {
  login: async ({ usernameId, password }) => {
    return merchantFetch("/api/merchant-auth/login", {
      method: "POST",
      body: { usernameId, password },
    });
  },
};

export const merchantProtectedApi = {
  getDashboard: async () => merchantFetch("/api/merchant/dashboard"),
  getCampaigns: async () => merchantFetch("/api/merchant/campaigns"),
  getMerchantConsolidatedStats: async (days) =>
    merchantFetch(`/api/campaign-stats/consolidated/daily/${days}`),
  issueCouponForCampaign: async (campaignId) =>
    merchantFetch(`/api/campaigns/${encodeURIComponent(campaignId)}/issue`, {
      method: "POST",
    }),
    getCampaignStats: async (campaignId, days)=>
      merchantFetch(`/api/campaign-stats/individual/campaign/${campaignId}/daily/${days}`),
  listCampaigns: async () =>
    merchantFetch("/api/campaigns/logged-in-merchant/campaigns"),
  getValidatedCoupons: async () =>
    merchantFetch("/api/redemption/logged-in-merchant/validated"),
  getMerchantNameId: async (merchantIdPk) =>
    merchantFetch(`/api/merchant/getMerchantNameId?merchantIdPk=${merchantIdPk}`),
  getProfile: async() =>merchantFetch("/api/merchant-profile/me"),

  // UPDATED: send RedemptionRequest payload
  // RedemptionRequest(UUID campaignId, String couponCode, Map<String, Object> extras, double billAmount)
  redeemCoupon: async (payload) =>
    merchantFetch(`/api/redemption/redeem`, {
      method: "POST",
      body: payload,
    }),
  createCampaign: async( payload )=>
    merchantFetch(`/api/campaigns/logged-in-merchant/create`, {
      method: "POST",
      body: payload,
    }),
  deactivateCampaign: async( campaignId )=>
    merchantFetch(`/api/campaigns/deactivate/${campaignId}`, {
      method: "PATCH"
    }),
  createEmployee: async(payload) =>
    merchantFetch(`/api/merchant/create-employee`, {
      method: "POST",
      body: payload,
    }),
};

export function redirectToMerchantLogin() {
  if (!window.location.pathname.startsWith("/merchant-login")) {
    clearMerchantAuth();
    window.location.href = "/merchant-login";
  }
}
