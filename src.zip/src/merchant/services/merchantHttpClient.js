// src/services/http.js
// Minimal fetch wrappers: publicFetch (no auth) and merchantFetch (adds Authorization if present)

import { clearMerchantAuth } from "../auth/merchantAuth";
import { redirectToMerchantLogin } from "./merchantProtectedApi.js";
import { getOrCreateDeviceId, merchantLocalStorage } from "./merchantDevice";

const API_BASE = "http://10.27.144.117:8080";



async function handleResponse(res) {
  // 🔐 Handle auth failures globally
  if (res.status === 401 || res.status === 403) {
    console.log("UnAuthorized")
    redirectToMerchantLogin();
    throw new Error("Unauthorized");
  }

  const contentType = res.headers.get("content-type") || "";
  const isJson = contentType.includes("application/json");
  const body = isJson
    ? await res.json().catch(() => null)
    : await res.text().catch(() => null);

  if (!res.ok) {
    const err = new Error(body?.message || res.statusText || "Request failed");
    err.status = res.status;
    err.body = body;
    throw err;
  }

  // ✅ your backend wraps data inside { data }
  return body?.data;
}

export async function httpPost(path, payload) {
  return request(path, {
    method: "POST",
    body: payload != null ? JSON.stringify(payload) : undefined,
  });
}

export async function merchantFetch(path, options = {}) {
  const url = `${API_BASE}${path}`;
  const merchantDeviceId = getOrCreateDeviceId();
  const token = merchantLocalStorage.getItem("accessToken");
  console.log("Token from merchantFetch" + token)

  const headers = {
    "Content-Type": "application/json",
    "X-Device-Id": merchantDeviceId,
    ...(options.headers || {}),
  };

  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  const res = await fetch(url, {
    credentials: "same-origin",
    headers,
    ...options,
    body:
      options.body && typeof options.body !== "string"
        ? JSON.stringify(options.body)
        : options.body,
  });

  return handleResponse(res);
}
